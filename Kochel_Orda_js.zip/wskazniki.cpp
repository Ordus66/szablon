#include<iostream>
#include<cstdlib>

using namespace std;

void zamien(int *a, int *b){
    int tmp = *a;
    *a = *b;
    *b = tmp;
}
 
void sortuj(int *a, int *b, int *c){
        if(*a>*b)
                zamien(a,b);
        if(*a>*c)
                zamien(a,c);
        if(*b>*c)
                zamien(b,c);
}
 
int main(){
        int a, b, c;
 
        cout<<"Podaj trzy liczby: "<<endl;
        cin>>a>>b>>c;
 
        sortuj(&a,&b,&c); //sortowanie liczb
 
        cout<<"Liczby posortowane: "<<a<<" "<<b<<" "<<c<<endl;

        return 0;
}